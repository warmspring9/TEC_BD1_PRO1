Este proyecto por ahora tiene dos vistas que son el dashboard y el log_in
falta toda la logica pero porfavor sigan la arquitectura de por cada vista o pagina tiene que haber un controller para sus eventos

falta hacer un controller para separar el main de la logica 
y que en el main solo esten las funciones del gui como exit y la de cambiar de paginas

lo bueno de usar javafx es que esta scenebuilder
para ver scenebuilder veanse un tutorial no hay muchos pero son buenos 
y pueden accesar el scenebuilder haciendo click derecho a los archivos .fxml y buscar el boton open in scenebuilder y ya 
es ultra facil hacer paginas ahi y los eventos se accesan dandole un nombre en el tab de code el botton o cosa y despues de hacer el evento 
ponerlo en el drop down del tab de code 

si tienen dudas me pueden preguntar