package Core;

import DataAccess.SQLDAO;

import java.util.List;

public class CoreController {
    /*SQLDAO dao = new SQLDAO();
    public CoreController(){

    }
    public List<String> LogIn(String user, String password){
        List<String> caca;
        caca = dao.mandarCositas(user,password,SQLOPERATION);
        return caca;
    }*/
}
/*
return all list<Dictionary<object>
return all comunidad
return by id
create ()
update
delete id*/